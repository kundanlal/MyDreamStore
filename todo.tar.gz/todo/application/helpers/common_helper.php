<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
function checkParam($param_fields, $value_array){       
    foreach($param_fields as $param){
        if(!isset($value_array[$param]) || null == $value_array[$param]){
            $resp = array(
                'status'=>false,
                'error'=>'Value missing',
                'field'=>$param
            );
            return $resp;
        }
    }
    return array('status'=>true,'error'=>'none', 'field'=>'none');
} 
