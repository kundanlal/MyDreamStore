<!doctype html>
<html>
    <head>
        <link rel='icon' href="<?php echo base_url('images/fav.png') ?>" type='image/png'>
        <title><?php echo $title; ?></title>
        <link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.min.css') ?>">
        <link rel="stylesheet" href="<?php echo base_url('assets/font-awesome/css/font-awesome.min.css') ?>">

        <script src="<?php echo base_url('assets/js/jquery-1.js') ?>"></script>
        <script src="<?php echo base_url('assets/js/bootstrap.min.js') ?>"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.4.8/angular.min.js"></script>
        <style>
            .bold{
                font-weight: bold;
            }
            .title{
                font-weight: bold;
            }
            .desc{
                font-size: 10px;
            }
            .height-limit-1{
                max-height: 300px;
                overflow-y: scroll;
            }
            .light{
                color:#999;
            }
        </style>
    </head>
    <body>
        <div class="container" ng-app="myApp" ng-controller="myCtrl">
            <div class="row">
                <div class="col-sm-12">
                    <h4 class="text-center page-header">To Do Task Assignment</h4>
                </div>
                <!-- Modal -->
                <div id="myModal" class="modal fade" role="dialog">
                    <div class="modal-dialog">

                        <!-- Modal content-->
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                                <h4 class="modal-title">Add New Task</h4>
                            </div>
                            <div class="modal-body">
                                <div class="form-group">
                                    <input type="text" name="task_title" placeholder="task title" class="form-control">
                                </div>
                                <div class="form-group">
                                    <textarea type="text" name="task_discription" class="form-control" rows="2"></textarea>
                                </div>
                                <div class="form-group">
                                    <button type="button" class="btn btn-success">SAVE</button>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="panel panel-warning">
                        <div class="panel-heading">
                            <span class="bold">Pending Task</span>
                            <button type="button" class="btn btn-success btn-xs pull-right" data-toggle="modal" data-target="#myModal">Add New Task</button>                                                           
                        </div>
                        <div class="panel-body height-limit-1">
                            <h3 ng-if="Ploading" class="text-center bold">Loading...</h3>
                            <div class="task" ng-repeat="row in pendingTask" id="task_{{row.seq_no}}">
                                <div class="col-xs-1">
                                    <input type="checkbox" value="{{row.seq_no}}" ng-click="markDone({{row.seq_no}})">
                                </div>                      
                                <div class="col-xs-11">
                                    <span class="title">{{row.tittle}}</span><br>
                                    <span class="desc">{{row.discription}}</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-sm-6">
                    <div class="panel panel-success">
                        <div class="panel-heading">
                            <span class="bold">Task Done</span>
                        </div>
                        <div class="panel-body height-limit-1">
                            <h3 ng-if="Dloading" class="text-center bold">Loading...</h3>
                            <div class="task" ng-repeat="r in doneTask" id="task_{{r.seq_no}}">
                                <div class="col-xs-1">
                                    <input type="checkbox" value="{{r.seq_no}}" ng-click="undo({{r.seq_no}})" checked="true">
                                </div>                      
                                <div class="col-xs-11">
                                    <span class="title light"><del>{{r.tittle}}</del></span><br>
                                    <span class="desc light"><del>{{r.discription}}</del></span>
                                </div>
                            </div>
                        </div>
                    </div>                   
                </div>                
            </div>
        </div>


        <script>
            //getPreventDefault();
            var base_url = 'http://localhost:8080/';
            var app = angular.module('myApp', []);
            app.controller('myCtrl', function ($scope, $http) {
            $scope.Ploading = true;
            $scope.Dloading = true;
            $scope.init = function (event) {
            $http({
            method: 'POST',
                    url: base_url + 'todo/index.php/Todo/showAllTask',
                    data: $.param({
                    status: "pending"
                    }),
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            }).success(function (data, status, headers, config) {
            $scope.Ploading = false;
            $scope.pendingTask = data.output;
            //console.log(data.output);
            }).error(function (data, status, headers, config) {
            // handle error things
            });
            //loading task done
            $http({
            method: 'POST',
                    url: base_url + 'todo/index.php/Todo/showAllTask',
                    data: $.param({
                    status: "done"
                    }),
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            }).success(function (data, status, headers, config) {
            $scope.Dloading = false;
            $scope.doneTask = data.output;
            //console.log(data.output);
            }).error(function (data, status, headers, config) {
            // handle error things
            });
            };
            $scope.init();
            $scope.markDone = function(id){
            console.log(id);
//                    $http({
//                        method: 'POST',
//                        url: base_url+'todo/index.php/Todo/markTaskDone',
//                        data: $.param({
//                            task_id:id
//                        }),
//                        headers: {'Content-Type': 'application/x-www-form-urlencoded'}
//                    }).success(function (data, status, headers, config) {
//                        //console.log(data.output);
//                        $('#task_'+id).remove();
//                        //$scope.init();
//                    }).error(function (data, status, headers, config) {
//                        // handle error things
//                    });
            };
            $scope.undo = function(id){
            $http({
            method: 'POST',
                    url: base_url + 'todo/index.php/Todo/undoMarkDone',
                    data: $.param({
                    task_id:id
                    }),
                    headers: {'Content-Type': 'application/x-www-form-urlencoded'}
            }).success(function (data, status, headers, config) {
            //console.log(data.output);
            $scope.init();
            }).error(function (data, status, headers, config) {
            // handle error things
            });
            };
            });
        </script>
    </body>
</html>