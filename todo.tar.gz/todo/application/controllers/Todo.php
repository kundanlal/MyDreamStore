<?php
defined('BASEPATH') OR exit('No direct script access allowed');


class Todo extends MY_Controller{
    function __construct() {
        parent::__construct();
        $this->load->helper(array('common'));
        $this->load->model('Todo_Model');
    }

    public function index(){        
        $data['title'] = "Todo Task";
        $this->load->view('homepage', $data);
    }

    public function showTask(){
        $param = $this->input->post();
        $param_field = array('task_id');
        $proceed = checkParam($param_field, $param);
        if(false == $proceed['status']){
            $this->response(400,'SHOW_TASK','parameter missing');
        }
        else{
            $taskRecord = $this->Todo_Model->get_task($param['task_id']);
            $this->response(200, "SHOW_TASK", "success", $taskRecord);
        }
    }
    
    public function showAllTask(){
        $param = $this->input->post();
        $param_field = array('status');
        $proceed = checkParam($param_field, $param);
        if(false == $proceed['status']){
            $this->response(400,'SHOW_ALL_TASK','parameter missing');
        }
        else{
            $taskRecord = $this->Todo_Model->get_all($param['status']);
            $this->response(200, "SHOW_ALL_TASK", "success", $taskRecord);
        }
    }

        public function addTask(){
        $param = $this->input->post();
        $param_field = array('title','discription');
        $proceed = checkParam($param_field, $param);
        if(false == $proceed['status']){
            $this->response(400,'ADD_TASK','parameter missing');
        }
        else{
            $id = $this->Todo_Model->add_task($param['title'], $param['discription']);
            if($id){
                $output = array('task_id'=>$id);
                $this->response(200, "ADD_TASK", "success", $output);
            }
            else{
                $this->response(400, "ADD_TASK", "failed to create task");
            }
        }
    }
    
    public function editTask(){
        $param = $this->input->post();
        $param_field = array('task_id','title','discription');
        $proceed = checkParam($param_field, $param);
        if(false == $proceed['status']){
            $this->response(400,'EDIT_TASK','parameter missing',array());
        }
        else{
            $update_record = array(
                'tittle'=>$param['title'],
                'discription'=>$param['discription'],
                'update_datetime'=>date('Y-m-d H:i:s'),
            );
            $status = $this->Todo_Model->update_task($param['task_id'], $update_record);
            if($status){                
                $this->response(200, "EDIT_TASK", "success");
            }
            else{
                $this->response(400, "EDIT_TASK", "failed to edit task");
            }
        }
    }
    
    public function markTaskDone(){
        $param = $this->input->post();
        $param_field = array('task_id');
        $proceed = checkParam($param_field, $param);
        if(false == $proceed['status']){
            $this->response(400,'TASK_DONE','parameter missing',array());
        }
        else{
            $update_record = array(
                'status'=>'done',
            );
            $status = $this->Todo_Model->update_task($param['task_id'], $update_record);
            if($status){                
                $this->response(200, "TASK_DONE", "success");
            }
            else{
                $this->response(400, "TASK_DONE", "failed to mark as task done");
            }
        }
    }
    
    public function undoMarkDone(){
        $param = $this->input->post();
        $param_field = array('task_id');
        $proceed = checkParam($param_field, $param);
        if(false == $proceed['status']){
            $this->response(400,'UNDO_TASK_DONE','parameter missing',array());
        }
        else{
            $update_record = array(
                'status'=>'pending',
            );
            $status = $this->Todo_Model->update_task($param['task_id'], $update_record);
            if($status){                
                $this->response(200, "UNDO_TASK_DONE", "success");
            }
            else{
                $this->response(400, "UNDO_TASK_DONE", "failed to undo task done");
            }
        }
    }

    public function deleteTask(){
        $param = $this->input->post();
        $param_field = array('task_id');
        $proceed = checkParam($param_field, $param);
        if(false == $proceed['status']){
            $this->response(400,'DELETE_TASK','parameter missing',array());
        }
        else{
            $update_record = array(
                'status'=>'pending',
            );
            $status = $this->Todo_Model->delete_task($param['task_id']);
            if($status){                
                $this->response(200, "DELETE_TASK", "success");
            }
            else{
                $this->response(400, "DELETE_TASK", "failed to delete task");
            }
        }
    }    
}
