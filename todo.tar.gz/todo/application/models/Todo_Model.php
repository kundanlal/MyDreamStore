<?php

class Todo_Model extends CI_Model {

    public $tableName = 'task';

    public function add_task($title, $discription, $owner = "ADMIN", $status = "pending") {
        try {
            $date_now = date('Y-m-d H:i:s');
            $data = array(
                'tittle' => $title,
                'discription' => $discription,
                'created_datetime' => $date_now,
                'update_datetime' => $date_now,
                'owner' => $owner,
                'status' => $status,
            );
            $this->db->insert($this->tableName, $data);
            $this->db->trans_complete();
            return $this->db->insert_id();
        } catch (Exception $e) {
            return false;
        }
    }

    public function get_all($status = "pending") {
        $query = $this->db->query("SELECT * FROM ".$this->tableName." where status='".$status."'");
        return $query->result_array();
    }

    public function get_task($id) {
        $query = $this->db->get_where($this->tableName, array('seq_no' => $id));
        return $query->result_array();
    }

    public function update_task($id, $data) {
        $this->db->where('seq_no', $id);
        $this->db->update($this->tableName, $data);
        return true;
    }

    public function delete_task($id) {
        $this->db->delete($this->tableName, array('seq_no' => $id));
        return true;
    }

}

?>